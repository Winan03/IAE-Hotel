package com.jean.hotel

data class RoomStatusUpdate(
    val reserved: Boolean
)
